﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImmoWEBProject
{
    internal class Klant
    {
        public int id { get; set; }
        public String naam { get; set; }
        public String straat { get; set; }
        public int huisnummer { get; set; }
        //public DateTimePicker inschrijving { get; set; }
        public String email { get; set; }
    }
}
