﻿namespace ImmoWEBProject
{
    partial class Specifiek_Klant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Id_label = new System.Windows.Forms.Label();
            this.Naam_label = new System.Windows.Forms.Label();
            this.Straat_label = new System.Windows.Forms.Label();
            this.Nummer_label = new System.Windows.Forms.Label();
            this.Email_label = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Delete_Client_Btn = new System.Windows.Forms.Button();
            this.Back_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Id:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Naam:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Straat:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 247);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nummer:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 301);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Email:";
            // 
            // Id_label
            // 
            this.Id_label.AutoSize = true;
            this.Id_label.Location = new System.Drawing.Point(126, 125);
            this.Id_label.Name = "Id_label";
            this.Id_label.Size = new System.Drawing.Size(38, 15);
            this.Id_label.TabIndex = 5;
            this.Id_label.Text = "label6";
            // 
            // Naam_label
            // 
            this.Naam_label.AutoSize = true;
            this.Naam_label.Location = new System.Drawing.Point(126, 164);
            this.Naam_label.Name = "Naam_label";
            this.Naam_label.Size = new System.Drawing.Size(38, 15);
            this.Naam_label.TabIndex = 6;
            this.Naam_label.Text = "label7";
            // 
            // Straat_label
            // 
            this.Straat_label.AutoSize = true;
            this.Straat_label.Location = new System.Drawing.Point(126, 205);
            this.Straat_label.Name = "Straat_label";
            this.Straat_label.Size = new System.Drawing.Size(38, 15);
            this.Straat_label.TabIndex = 7;
            this.Straat_label.Text = "label8";
            // 
            // Nummer_label
            // 
            this.Nummer_label.AutoSize = true;
            this.Nummer_label.Location = new System.Drawing.Point(126, 247);
            this.Nummer_label.Name = "Nummer_label";
            this.Nummer_label.Size = new System.Drawing.Size(38, 15);
            this.Nummer_label.TabIndex = 8;
            this.Nummer_label.Text = "label9";
            // 
            // Email_label
            // 
            this.Email_label.AutoSize = true;
            this.Email_label.Location = new System.Drawing.Point(126, 301);
            this.Email_label.Name = "Email_label";
            this.Email_label.Size = new System.Drawing.Size(44, 15);
            this.Email_label.TabIndex = 9;
            this.Email_label.Text = "label10";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(62, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(186, 39);
            this.label6.TabIndex = 10;
            this.label6.Text = "Klantinformatie";
            // 
            // Delete_Client_Btn
            // 
            this.Delete_Client_Btn.Location = new System.Drawing.Point(63, 343);
            this.Delete_Client_Btn.Name = "Delete_Client_Btn";
            this.Delete_Client_Btn.Size = new System.Drawing.Size(117, 41);
            this.Delete_Client_Btn.TabIndex = 11;
            this.Delete_Client_Btn.Text = "Delete Klant";
            this.Delete_Client_Btn.UseVisualStyleBackColor = true;
            this.Delete_Client_Btn.Click += new System.EventHandler(this.Delete_Client_Btn_Click);
            // 
            // Back_btn
            // 
            this.Back_btn.Location = new System.Drawing.Point(201, 343);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(117, 41);
            this.Back_btn.TabIndex = 12;
            this.Back_btn.Text = "Go Back To Catalog";
            this.Back_btn.UseVisualStyleBackColor = true;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // Specifiek_Klant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(360, 424);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.Delete_Client_Btn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Email_label);
            this.Controls.Add(this.Nummer_label);
            this.Controls.Add(this.Straat_label);
            this.Controls.Add(this.Naam_label);
            this.Controls.Add(this.Id_label);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "Specifiek_Klant";
            this.Text = "Specifiek_Klant";
            this.Load += new System.EventHandler(this.Specifiek_Klant_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        public Label Id_label;
        public Label Naam_label;
        public Label Straat_label;
        public Label Nummer_label;
        public Label Email_label;
        private Label label6;
        private Button Delete_Client_Btn;
        private Button Back_btn;
    }
}