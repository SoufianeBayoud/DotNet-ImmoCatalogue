﻿namespace ImmoWEBProject
{
    partial class Specifieke_Immo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nz = new System.Windows.Forms.Label();
            this.st = new System.Windows.Forms.Label();
            this.nr = new System.Windows.Forms.Label();
            this.lb = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Ps = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Naam_label = new System.Windows.Forms.Label();
            this.Straat_label = new System.Windows.Forms.Label();
            this.Nummer_label = new System.Windows.Forms.Label();
            this.Gemeente_label = new System.Windows.Forms.Label();
            this.Bouwjaar_label = new System.Windows.Forms.Label();
            this.Grootte_label = new System.Windows.Forms.Label();
            this.Kamers_label = new System.Windows.Forms.Label();
            this.Prijs_label = new System.Windows.Forms.Label();
            this.Tuin_label = new System.Windows.Forms.Label();
            this.Type_label = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.Id_label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Contact_Btn = new System.Windows.Forms.Button();
            this.Delete_Btn = new System.Windows.Forms.Button();
            this.Go_Back_Btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nz
            // 
            this.nz.AutoSize = true;
            this.nz.Location = new System.Drawing.Point(59, 136);
            this.nz.Name = "nz";
            this.nz.Size = new System.Drawing.Size(42, 15);
            this.nz.TabIndex = 0;
            this.nz.Text = "Naam:";
            // 
            // st
            // 
            this.st.AutoSize = true;
            this.st.Location = new System.Drawing.Point(59, 174);
            this.st.Name = "st";
            this.st.Size = new System.Drawing.Size(40, 15);
            this.st.TabIndex = 1;
            this.st.Text = "Straat:";
            // 
            // nr
            // 
            this.nr.AutoSize = true;
            this.nr.Location = new System.Drawing.Point(59, 215);
            this.nr.Name = "nr";
            this.nr.Size = new System.Drawing.Size(58, 15);
            this.nr.TabIndex = 2;
            this.nr.Text = "Nummer:";
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.Location = new System.Drawing.Point(59, 254);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(64, 15);
            this.lb.TabIndex = 3;
            this.lb.Text = "Gemeente:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(59, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Bouwjaar:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(59, 334);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Grootte:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(59, 381);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Kamers:";
            // 
            // Ps
            // 
            this.Ps.AutoSize = true;
            this.Ps.Location = new System.Drawing.Point(59, 423);
            this.Ps.Name = "Ps";
            this.Ps.Size = new System.Drawing.Size(32, 15);
            this.Ps.TabIndex = 7;
            this.Ps.Text = "Prijs:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(59, 460);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 15);
            this.label9.TabIndex = 8;
            this.label9.Text = "Tuin (Ja/Neen):";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(59, 506);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Type:";
            // 
            // Naam_label
            // 
            this.Naam_label.AutoSize = true;
            this.Naam_label.Location = new System.Drawing.Point(157, 136);
            this.Naam_label.Name = "Naam_label";
            this.Naam_label.Size = new System.Drawing.Size(44, 15);
            this.Naam_label.TabIndex = 10;
            this.Naam_label.Text = "label11";
            // 
            // Straat_label
            // 
            this.Straat_label.AutoSize = true;
            this.Straat_label.Location = new System.Drawing.Point(157, 174);
            this.Straat_label.Name = "Straat_label";
            this.Straat_label.Size = new System.Drawing.Size(44, 15);
            this.Straat_label.TabIndex = 11;
            this.Straat_label.Text = "label12";
            // 
            // Nummer_label
            // 
            this.Nummer_label.AutoSize = true;
            this.Nummer_label.Location = new System.Drawing.Point(157, 215);
            this.Nummer_label.Name = "Nummer_label";
            this.Nummer_label.Size = new System.Drawing.Size(44, 15);
            this.Nummer_label.TabIndex = 12;
            this.Nummer_label.Text = "label13";
            // 
            // Gemeente_label
            // 
            this.Gemeente_label.AutoSize = true;
            this.Gemeente_label.Location = new System.Drawing.Point(157, 254);
            this.Gemeente_label.Name = "Gemeente_label";
            this.Gemeente_label.Size = new System.Drawing.Size(44, 15);
            this.Gemeente_label.TabIndex = 13;
            this.Gemeente_label.Text = "label14";
            // 
            // Bouwjaar_label
            // 
            this.Bouwjaar_label.AutoSize = true;
            this.Bouwjaar_label.Location = new System.Drawing.Point(157, 291);
            this.Bouwjaar_label.Name = "Bouwjaar_label";
            this.Bouwjaar_label.Size = new System.Drawing.Size(44, 15);
            this.Bouwjaar_label.TabIndex = 14;
            this.Bouwjaar_label.Text = "label15";
            // 
            // Grootte_label
            // 
            this.Grootte_label.AutoSize = true;
            this.Grootte_label.Location = new System.Drawing.Point(157, 334);
            this.Grootte_label.Name = "Grootte_label";
            this.Grootte_label.Size = new System.Drawing.Size(44, 15);
            this.Grootte_label.TabIndex = 15;
            this.Grootte_label.Text = "label16";
            // 
            // Kamers_label
            // 
            this.Kamers_label.AutoSize = true;
            this.Kamers_label.Location = new System.Drawing.Point(157, 381);
            this.Kamers_label.Name = "Kamers_label";
            this.Kamers_label.Size = new System.Drawing.Size(44, 15);
            this.Kamers_label.TabIndex = 16;
            this.Kamers_label.Text = "label17";
            // 
            // Prijs_label
            // 
            this.Prijs_label.AutoSize = true;
            this.Prijs_label.Location = new System.Drawing.Point(157, 423);
            this.Prijs_label.Name = "Prijs_label";
            this.Prijs_label.Size = new System.Drawing.Size(44, 15);
            this.Prijs_label.TabIndex = 17;
            this.Prijs_label.Text = "label18";
            // 
            // Tuin_label
            // 
            this.Tuin_label.AutoSize = true;
            this.Tuin_label.Location = new System.Drawing.Point(157, 460);
            this.Tuin_label.Name = "Tuin_label";
            this.Tuin_label.Size = new System.Drawing.Size(44, 15);
            this.Tuin_label.TabIndex = 18;
            this.Tuin_label.Text = "label19";
            // 
            // Type_label
            // 
            this.Type_label.AutoSize = true;
            this.Type_label.Location = new System.Drawing.Point(157, 506);
            this.Type_label.Name = "Type_label";
            this.Type_label.Size = new System.Drawing.Size(44, 15);
            this.Type_label.TabIndex = 19;
            this.Type_label.Text = "label20";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(58, 45);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(128, 21);
            this.label21.TabIndex = 20;
            this.label21.Text = "Immogegevens";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // Id_label
            // 
            this.Id_label.AutoSize = true;
            this.Id_label.Location = new System.Drawing.Point(157, 96);
            this.Id_label.Name = "Id_label";
            this.Id_label.Size = new System.Drawing.Size(32, 15);
            this.Id_label.TabIndex = 21;
            this.Id_label.Text = "label";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 15);
            this.label2.TabIndex = 22;
            this.label2.Text = "Id:";
            // 
            // Contact_Btn
            // 
            this.Contact_Btn.Location = new System.Drawing.Point(343, 132);
            this.Contact_Btn.Name = "Contact_Btn";
            this.Contact_Btn.Size = new System.Drawing.Size(124, 34);
            this.Contact_Btn.TabIndex = 23;
            this.Contact_Btn.Text = "Contact Owner";
            this.Contact_Btn.UseVisualStyleBackColor = true;
            this.Contact_Btn.Click += new System.EventHandler(this.Contact_Btn_Click);
            // 
            // Delete_Btn
            // 
            this.Delete_Btn.Location = new System.Drawing.Point(343, 174);
            this.Delete_Btn.Name = "Delete_Btn";
            this.Delete_Btn.Size = new System.Drawing.Size(124, 34);
            this.Delete_Btn.TabIndex = 24;
            this.Delete_Btn.Text = "Delete";
            this.Delete_Btn.UseVisualStyleBackColor = true;
            this.Delete_Btn.Click += new System.EventHandler(this.Delete_Btn_Click);
            // 
            // Go_Back_Btn
            // 
            this.Go_Back_Btn.Location = new System.Drawing.Point(343, 215);
            this.Go_Back_Btn.Name = "Go_Back_Btn";
            this.Go_Back_Btn.Size = new System.Drawing.Size(125, 34);
            this.Go_Back_Btn.TabIndex = 25;
            this.Go_Back_Btn.Text = "Go Back to Catalog";
            this.Go_Back_Btn.UseVisualStyleBackColor = true;
            this.Go_Back_Btn.Click += new System.EventHandler(this.Go_Back_Btn_Click);
            // 
            // Specifieke_Immo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(583, 554);
            this.Controls.Add(this.Go_Back_Btn);
            this.Controls.Add(this.Delete_Btn);
            this.Controls.Add(this.Contact_Btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Id_label);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.Type_label);
            this.Controls.Add(this.Tuin_label);
            this.Controls.Add(this.Prijs_label);
            this.Controls.Add(this.Kamers_label);
            this.Controls.Add(this.Grootte_label);
            this.Controls.Add(this.Bouwjaar_label);
            this.Controls.Add(this.Gemeente_label);
            this.Controls.Add(this.Nummer_label);
            this.Controls.Add(this.Straat_label);
            this.Controls.Add(this.Naam_label);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Ps);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lb);
            this.Controls.Add(this.nr);
            this.Controls.Add(this.st);
            this.Controls.Add(this.nz);
            this.Name = "Specifieke_Immo";
            this.Text = "Specifieke_Immo";
            this.Load += new System.EventHandler(this.Specifieke_Immo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label nz;
        private Label st;
        private Label nr;
        private Label lb;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label Ps;
        private Label label9;
        private Label label10;
        private Label label21;
        private Label label2;
        public Label Naam_label;
        public Label Straat_label;
        public Label Nummer_label;
        public Label Gemeente_label;
        public Label Bouwjaar_label;
        public Label Grootte_label;
        public Label Kamers_label;
        public Label Prijs_label;
        public Label Tuin_label;
        public Label Type_label;
        public Label Id_label;
        private Button Contact_Btn;
        private Button Delete_Btn;
        private Button Go_Back_Btn;
    }
}