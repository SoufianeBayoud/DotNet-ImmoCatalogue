﻿namespace ImmoWEBProject
{
    partial class AddImmo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Naam_tb = new System.Windows.Forms.TextBox();
            this.Straat_tb = new System.Windows.Forms.TextBox();
            this.Nummer_tb = new System.Windows.Forms.TextBox();
            this.Gemeente_tb = new System.Windows.Forms.TextBox();
            this.Bouwjaar_tb = new System.Windows.Forms.TextBox();
            this.Grootte_tb = new System.Windows.Forms.TextBox();
            this.Kamers_tb = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Prijs_tb = new System.Windows.Forms.TextBox();
            this.Tuin_tb = new System.Windows.Forms.TextBox();
            this.Type_tb = new System.Windows.Forms.TextBox();
            this.AddImmo_Btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Naam:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Adres";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(186, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Straat:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(146, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Huisnummer:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(162, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Postcode:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(69, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Bouwjaar:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(212, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Grootte:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(69, 217);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "Tuin (Ja/Neen):";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(242, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 15);
            this.label9.TabIndex = 8;
            this.label9.Text = "Type:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(376, 179);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Kamers:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(333, 179);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 15);
            this.label11.TabIndex = 10;
            this.label11.Text = "m²";
            // 
            // Naam_tb
            // 
            this.Naam_tb.Location = new System.Drawing.Point(117, 43);
            this.Naam_tb.Name = "Naam_tb";
            this.Naam_tb.Size = new System.Drawing.Size(671, 23);
            this.Naam_tb.TabIndex = 11;
            // 
            // Straat_tb
            // 
            this.Straat_tb.Location = new System.Drawing.Point(242, 79);
            this.Straat_tb.Name = "Straat_tb";
            this.Straat_tb.Size = new System.Drawing.Size(546, 23);
            this.Straat_tb.TabIndex = 12;
            // 
            // Nummer_tb
            // 
            this.Nummer_tb.Location = new System.Drawing.Point(242, 108);
            this.Nummer_tb.Name = "Nummer_tb";
            this.Nummer_tb.Size = new System.Drawing.Size(546, 23);
            this.Nummer_tb.TabIndex = 13;
            this.Nummer_tb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Nummer_tb_KeyPress);
            // 
            // Gemeente_tb
            // 
            this.Gemeente_tb.Location = new System.Drawing.Point(242, 136);
            this.Gemeente_tb.Name = "Gemeente_tb";
            this.Gemeente_tb.Size = new System.Drawing.Size(546, 23);
            this.Gemeente_tb.TabIndex = 14;
            this.Gemeente_tb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Gemeente_tb_KeyPress);
            // 
            // Bouwjaar_tb
            // 
            this.Bouwjaar_tb.Location = new System.Drawing.Point(134, 176);
            this.Bouwjaar_tb.Name = "Bouwjaar_tb";
            this.Bouwjaar_tb.Size = new System.Drawing.Size(53, 23);
            this.Bouwjaar_tb.TabIndex = 15;
            this.Bouwjaar_tb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Bouwjaar_tb_KeyPress);
            // 
            // Grootte_tb
            // 
            this.Grootte_tb.Location = new System.Drawing.Point(268, 176);
            this.Grootte_tb.Name = "Grootte_tb";
            this.Grootte_tb.Size = new System.Drawing.Size(57, 23);
            this.Grootte_tb.TabIndex = 16;
            this.Grootte_tb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Grootte_tb_KeyPress);
            // 
            // Kamers_tb
            // 
            this.Kamers_tb.Location = new System.Drawing.Point(431, 176);
            this.Kamers_tb.Name = "Kamers_tb";
            this.Kamers_tb.Size = new System.Drawing.Size(54, 23);
            this.Kamers_tb.TabIndex = 17;
            this.Kamers_tb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Kamers_tb_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(629, 179);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(13, 15);
            this.label12.TabIndex = 18;
            this.label12.Text = "€";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(514, 179);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(32, 15);
            this.label13.TabIndex = 19;
            this.label13.Text = "Prijs:";
            // 
            // Prijs_tb
            // 
            this.Prijs_tb.Location = new System.Drawing.Point(552, 176);
            this.Prijs_tb.Name = "Prijs_tb";
            this.Prijs_tb.Size = new System.Drawing.Size(71, 23);
            this.Prijs_tb.TabIndex = 20;
            this.Prijs_tb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Prijs_tb_KeyPress);
            // 
            // Tuin_tb
            // 
            this.Tuin_tb.Location = new System.Drawing.Point(162, 214);
            this.Tuin_tb.Name = "Tuin_tb";
            this.Tuin_tb.Size = new System.Drawing.Size(53, 23);
            this.Tuin_tb.TabIndex = 21;
            // 
            // Type_tb
            // 
            this.Type_tb.Location = new System.Drawing.Point(283, 214);
            this.Type_tb.Name = "Type_tb";
            this.Type_tb.Size = new System.Drawing.Size(119, 23);
            this.Type_tb.TabIndex = 22;
            // 
            // AddImmo_Btn
            // 
            this.AddImmo_Btn.Location = new System.Drawing.Point(514, 278);
            this.AddImmo_Btn.Name = "AddImmo_Btn";
            this.AddImmo_Btn.Size = new System.Drawing.Size(184, 51);
            this.AddImmo_Btn.TabIndex = 23;
            this.AddImmo_Btn.Text = "Toevoegen";
            this.AddImmo_Btn.UseVisualStyleBackColor = true;
            this.AddImmo_Btn.Click += new System.EventHandler(this.AddImmo_Btn_Click);
            // 
            // AddImmo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.AddImmo_Btn);
            this.Controls.Add(this.Type_tb);
            this.Controls.Add(this.Tuin_tb);
            this.Controls.Add(this.Prijs_tb);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Kamers_tb);
            this.Controls.Add(this.Grootte_tb);
            this.Controls.Add(this.Bouwjaar_tb);
            this.Controls.Add(this.Gemeente_tb);
            this.Controls.Add(this.Nummer_tb);
            this.Controls.Add(this.Straat_tb);
            this.Controls.Add(this.Naam_tb);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AddImmo";
            this.Text = "AddImmo";
            this.Load += new System.EventHandler(this.AddImmo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private TextBox Naam_tb;
        private TextBox Straat_tb;
        private TextBox Nummer_tb;
        private TextBox Gemeente_tb;
        private TextBox Bouwjaar_tb;
        private TextBox Grootte_tb;
        private TextBox Kamers_tb;
        private Label label12;
        private Label label13;
        private TextBox Prijs_tb;
        private TextBox Tuin_tb;
        private TextBox Type_tb;
        private Button AddImmo_Btn;
    }
}